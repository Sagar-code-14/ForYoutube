<?php
/*PL Means Page Label*/
function contactPL()
{
	echo "Contact Us";
}


function officeWorksPL()
{
	echo "Office & Works";
}

?>
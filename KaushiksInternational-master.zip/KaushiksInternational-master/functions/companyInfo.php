<?php

function companyName()
{
	echo "Kaushiks International";
}
function officeWorks()
{
	echo "3407, 2nd Cross, 10th Main,<br>
	2nd Stage Indiranagar,<br>
	Bangalore - 560038";
}

function registeredAddress()
{
	echo "454, 1st Cross, 1st Stage,<br>
	Krishna Temple Road,<br>
	Indiranagar,<br>
	Bangalore - 560038";
}

function tel()
{
	echo "+91-80-25288286";
}

function email()
{
	echo "info@kaushiksinternational.com";
}

?>